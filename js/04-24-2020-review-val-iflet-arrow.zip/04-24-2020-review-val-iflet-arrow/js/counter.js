// counterTextBox
// startCounterButton

let counterTextBox = document.getElementById("counterTextBox")
let startCounterButton = document.getElementById("startCounterButton")

let counterHeading = document.getElementById("counterHeading")

function foo() {
    console.log("foo")
}


startCounterButton.addEventListener("click", function() {

    displayNews() 

    let value = counterTextBox.value
    console.log(value)

    foo() 

    // start the count down timer using set interval 
    let id = setInterval(function() {

        console.log("tick")

        // change the background of the body to green 
        document.body.style.background = "green" 

        // how can we assign 20 to counter Heading so it gets displayed on the screen 
        counterHeading.innerHTML = value

        value = value - 1

        if (value < 0) {
            document.body.style.background = "red"
            // stop the interval
            clearInterval(id)
        }

        // display the count down on the screen 




    }, 1000);



})





