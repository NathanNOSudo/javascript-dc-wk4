let stockSymbolTextBox = document.getElementById("stockSymbolTextBox")
let getQuoteButton = document.getElementById("getQuoteButton")

// stockQuoteHeading is H1 element 
let stockQuoteHeading = document.getElementById("stockQuoteHeading")

// ARROW FUNCTIONS 
/*
getQuoteButton.addEventListener("click",() => {
    console.log(this)
    let symbol = stockSymbolTextBox.value
}) */

// ARROW FUNCTIONS
/*
setTimeout(() => {

},3000) */


getQuoteButton.addEventListener("click", function() {

    console.log(this)

    let symbol = stockSymbolTextBox.value

    setInterval(function () {

        // every three seconds we want to get the updated quote 
        let stockQuote = getStockQuote(symbol)
        stockQuoteHeading.innerHTML = `${stockQuote.name} - $${stockQuote.price}`

    }, 3000)


    // {name: "Apple", price: 227}
   
})


// Difference between let and var 

function sayGreetings() {

    var name = "John" 
    //const pi = 3.142

    // variable hoisting 
    if(1 == 1) {
        var name = "Mary"
        let age = 23 
        const pi = 4.2
        pi = 4.0 // ERROR because const is only assigned ONCE and cannot be changed
        console.log(age)
    }

    //console.log(pi)
    console.log(name)
    console.log(age)

}

sayGreetings() 
